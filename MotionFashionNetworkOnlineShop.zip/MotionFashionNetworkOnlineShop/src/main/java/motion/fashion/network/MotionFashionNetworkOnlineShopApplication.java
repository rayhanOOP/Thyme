package motion.fashion.network;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MotionFashionNetworkOnlineShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(MotionFashionNetworkOnlineShopApplication.class, args);
	}
}
